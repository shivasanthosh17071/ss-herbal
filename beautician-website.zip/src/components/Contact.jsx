"use client"

function Contact() {
  const handleWhatsApp = () => {
    // Replace 1234567890 with the actual WhatsApp number
    window.open("https://wa.me/1234567890", "_blank")
  }

  const handleCall = () => {
    // Replace 1234567890 with the actual phone number
    window.location.href = "tel:1234567890"
  }

  const handleEmail = () => {
    // Replace email@example.com with the actual email
    window.location.href = "mailto:email@example.com"
  }

  return (
    <section id="contact" style={{ backgroundColor: "white", padding: "6rem 0" }}>
      <div className="container">
        <div className="text-center mb-5">
          <h6
            style={{
              color: "#FF6B98",
              fontWeight: "600",
              letterSpacing: "2px",
              marginBottom: "15px",
            }}
          >
            CONTACT US
          </h6>

          <h2 className="section-title" style={{ fontSize: "2.5rem" }}>
            Get In Touch With Us
          </h2>

          <p
            className="mx-auto"
            style={{
              maxWidth: "700px",
              fontSize: "1.1rem",
              color: "#666",
            }}
          >
            Have questions or want to book an appointment? Reach out to us through any of the following channels.
          </p>
        </div>

        <div className="row g-4">
          <div className="col-lg-6 mb-4 mb-lg-0">
            <div
              style={{
                backgroundColor: "#f9f9f9",
                borderRadius: "15px",
                padding: "30px",
                height: "100%",
                boxShadow: "0 5px 15px rgba(0,0,0,0.05)",
              }}
            >
              <h4 style={{ color: "#4A0025", marginBottom: "30px" }}>Contact Information</h4>

              <div className="d-flex align-items-center mb-4">
                <div
                  style={{
                    width: "60px",
                    height: "60px",
                    borderRadius: "50%",
                    backgroundColor: "rgba(255, 107, 152, 0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: "20px",
                  }}
                >
                  <i className="bi bi-geo-alt" style={{ color: "#FF6B98", fontSize: "1.8rem" }}></i>
                </div>
                <div>
                  <h5 style={{ margin: "0", fontWeight: "600" }}>Our Location</h5>
                  <p style={{ margin: "0", color: "#666" }}>123 Beauty Street, Fashion Avenue, City - 400001</p>
                </div>
              </div>

              <div className="d-flex align-items-center mb-4">
                <div
                  style={{
                    width: "60px",
                    height: "60px",
                    borderRadius: "50%",
                    backgroundColor: "rgba(138, 79, 255, 0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: "20px",
                  }}
                >
                  <i className="bi bi-telephone" style={{ color: "#8A4FFF", fontSize: "1.8rem" }}></i>
                </div>
                <div>
                  <h5 style={{ margin: "0", fontWeight: "600" }}>Call Us</h5>
                  <p style={{ margin: "0", color: "#666" }}>+91 1234567890</p>
                </div>
              </div>

              <div className="d-flex align-items-center mb-4">
                <div
                  style={{
                    width: "60px",
                    height: "60px",
                    borderRadius: "50%",
                    backgroundColor: "rgba(255, 215, 0, 0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: "20px",
                  }}
                >
                  <i className="bi bi-envelope" style={{ color: "#FFD700", fontSize: "1.8rem" }}></i>
                </div>
                <div>
                  <h5 style={{ margin: "0", fontWeight: "600" }}>Email Us</h5>
                  <p style={{ margin: "0", color: "#666" }}>info@glambeauty.com</p>
                </div>
              </div>

              <div className="d-flex align-items-center">
                <div
                  style={{
                    width: "60px",
                    height: "60px",
                    borderRadius: "50%",
                    backgroundColor: "rgba(74, 0, 37, 0.1)",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    marginRight: "20px",
                  }}
                >
                  <i className="bi bi-clock" style={{ color: "#4A0025", fontSize: "1.8rem" }}></i>
                </div>
                <div>
                  <h5 style={{ margin: "0", fontWeight: "600" }}>Business Hours</h5>
                  <p style={{ margin: "0", color: "#666" }}>Mon-Fri: 10AM-8PM, Sat: 9AM-9PM, Sun: 10AM-6PM</p>
                </div>
              </div>

              <div className="mt-5">
                <h5 style={{ marginBottom: "15px" }}>Connect With Us</h5>
                <div className="d-flex">
                  <a
                    href="https://wa.me/1234567890"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="social-icon me-2"
                    style={{
                      backgroundColor: "#25D366",
                      color: "white",
                    }}
                  >
                    <i className="bi bi-whatsapp"></i>
                  </a>
                  <a
                    href="https://instagram.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="social-icon me-2"
                    style={{
                      backgroundColor: "#E1306C",
                      color: "white",
                    }}
                  >
                    <i className="bi bi-instagram"></i>
                  </a>
                  <a
                    href="https://facebook.com"
                    target="_blank"
                    rel="noopener noreferrer"
                    className="social-icon"
                    style={{
                      backgroundColor: "#1877F2",
                      color: "white",
                    }}
                  >
                    <i className="bi bi-facebook"></i>
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div className="col-lg-6">
            <div
              style={{
                borderRadius: "15px",
                overflow: "hidden",
                boxShadow: "0 5px 15px rgba(0,0,0,0.1)",
                height: "100%",
              }}
            >
              {/* Google Maps Embed Placeholder */}
              <div
                style={{
                  width: "100%",
                  height: "300px",
                  backgroundColor: "#eee",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <p style={{ color: "#666" }}>Google Maps would be embedded here in the live website.</p>
              </div>

              <div
                style={{
                  backgroundColor: "#FF6B98",
                  padding: "30px",
                  color: "white",
                }}
              >
                <h4 style={{ marginBottom: "20px" }}>Quick Contact</h4>

                <div className="row g-3">
                  <div className="col-md-4">
                    <button
                      className="btn btn-light w-100"
                      style={{
                        borderRadius: "10px",
                        padding: "15px",
                        fontWeight: "600",
                      }}
                      onClick={handleWhatsApp}
                    >
                      <i className="bi bi-whatsapp me-2"></i> WhatsApp
                    </button>
                  </div>

                  <div className="col-md-4">
                    <button
                      className="btn btn-light w-100"
                      style={{
                        borderRadius: "10px",
                        padding: "15px",
                        fontWeight: "600",
                      }}
                      onClick={handleCall}
                    >
                      <i className="bi bi-telephone me-2"></i> Call
                    </button>
                  </div>

                  <div className="col-md-4">
                    <button
                      className="btn btn-light w-100"
                      style={{
                        borderRadius: "10px",
                        padding: "15px",
                        fontWeight: "600",
                      }}
                      onClick={handleEmail}
                    >
                      <i className="bi bi-envelope me-2"></i> Email
                    </button>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default Contact
